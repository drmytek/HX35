Editor NUR F�R HX3.5 ab Version 5.06!
Enthaltene Dateien m�ssen in EINEM Ordner liegen.

-cm
